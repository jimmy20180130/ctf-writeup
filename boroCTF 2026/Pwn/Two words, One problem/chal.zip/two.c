#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFSIZE 37
#define FLAGSIZE 64

int main() {
    printf("%s", "Hey, I made a typo and now have a string that I can't change. Can you fix it for me?\n");
    char non_constant[BUFFSIZE] = "I love";
    const char constant[BUFFSIZE] = "barackCTF";
    while (1) {
        menu();
        char choice[BUFFSIZE];
        fgets(choice, 3, stdin);
        choice[strcspn(choice, "\r\n")] = 0;
        if (strcmp(choice, "1") == 0) {
            check(non_constant, constant);
        } else if (strcmp(choice, "2") == 0) {
            change(non_constant);
        }

    }
    return 0;
}

void check(char *nc, char *c) {
    printf("%s %s!\n", nc, c);
    if (strcmp(c, "boroCTF") == 0) {
        char flag[FLAGSIZE];
        FILE * f = fopen("flag.txt", "r");
        fgets(flag, FLAGSIZE, f);
        printf("%s\n", flag);
    }
    return;
}

void change(char *nc) {
    printf("What would like to write?\n> ");
    gets(nc);
    return;
}

void menu() {
    printf("%s", "[1] - Read values\n");
    printf("%s", "[2] - Write value\n> ");
    return;
}