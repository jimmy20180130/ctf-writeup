#!/bin/sh
export LD_PRELOAD=/lib/unbuffer.so
exec /app/chal
