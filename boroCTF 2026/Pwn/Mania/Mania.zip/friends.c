#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define FRIENDSIZE 32
#define BUFFSIZE 32

struct __attribute__((packed)) imaginaryFriend {
    double rating;
    char title[FRIENDSIZE];
    char special_ability[FRIENDSIZE];
};

struct __attribute__((packed)) realPerson {
    char firstName[BUFFSIZE];
    char lastName[BUFFSIZE];
    void (*conversate)();
};

void menu();
struct imaginaryFriend *imagine();
struct realPerson *meet();
void realConversation();
void idealConversation();

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    puts("My conversations with my imaginary friends don't feel real anymore.");
    puts("Can you help me get out of my shell?");

    struct imaginaryFriend *IF = NULL;
    struct realPerson *RF = NULL;

    while (1) {
        char buf[BUFFSIZE];
        menu();
        fgets(buf, sizeof(buf), stdin);
        char choice = buf[0];

        switch (choice) {
            case '1':
                IF = imagine();
                break;
            case '2':
                free(IF);
                break;
            case '3':
                RF = meet();
                break;
            case '4':
                free(RF);
                break;
            case '5':
                if (RF != NULL) {
                    RF->conversate();
                } else {
                    puts("You haven't met anyone yet!");
                }
                break;
            default:
                puts("Unknown.");
                exit(1);
        }
    }
}

void menu() {
    puts("[1] - Imagine friend");
    puts("[2] - Forget friend");
    puts("[3] - Meet person");
    puts("[4] - Ghost person");
    puts("[5] - Interact");
    fputs("> ", stdout);
    fflush(stdout);
}

struct imaginaryFriend *imagine() {

    struct imaginaryFriend *friend = malloc(sizeof(struct imaginaryFriend));
    char buf[BUFFSIZE >> 1];

    puts("Enter title: ");
    fgets(friend->title, sizeof(friend->title), stdin);
    friend->title[strcspn(friend->title, "\r\n")] = 0;

    puts("Enter special ability: ");
    fgets(friend->special_ability, sizeof(friend->special_ability), stdin);
    friend->special_ability[strcspn(friend->special_ability, "\r\n")] = 0;

    puts("Enter rating: ");
    if (fgets(buf, sizeof(buf), stdin)) {
        friend->rating = strtod(buf, NULL);
    } else {
        friend->rating = 0.0;
    }

    printf("Imagined '%s' with ability '%s' (rating %.1f)!\n", friend->title, friend->special_ability, friend->rating);
    return friend;
}

struct realPerson *meet() {

    struct realPerson *friend = malloc(sizeof(struct realPerson));

    puts("Enter firstName: ");
    fgets(friend->firstName, sizeof(friend->firstName), stdin);
    friend->firstName[strcspn(friend->firstName, "\r\n")] = 0;

    puts("Enter lastName: ");
    fgets(friend->lastName, sizeof(friend->lastName), stdin);
    friend->lastName[strcspn(friend->lastName, "\r\n")] = 0;

    friend->conversate = realConversation;

    printf("Met '%s %s'!\n", friend->firstName, friend->lastName);
    return friend;
}

void realConversation() {
    puts("They brushed you off.");
}

void idealConversation() {
    puts("Wow! You made a real connection!");
    system("/bin/sh");
}
